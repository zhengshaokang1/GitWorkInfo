﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfStudy
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public string connectString_Center = @"Data Source = 127.0.0.1; Initial Catalog = PACSSelfService; User ID = sa; Password =123456";
        //每页显示5条记录
        public const int pageSize = 2;

        public MainWindow()
        {
            InitializeComponent();
            string study_state = txt_state.Text;
            string series_modality = txt_modality.Text;
            string starttime = date_starttime.Text;
            string endtime = date_endtime.Text;
            int pageindex = Convert.ToInt32(label1.Content);
            GetData(pageindex, study_state, series_modality, starttime, endtime);
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            string study_state = txt_state.Text;
            string series_modality = txt_modality.Text;
            string starttime = date_starttime.Text;
            string endtime = date_endtime.Text;
            int pageindex = Convert.ToInt32(label1.Content);
            GetData(pageindex, study_state, series_modality, starttime, endtime);
        }
        /// <summary>
        /// 数据库绑定数据
        /// </summary>
        private void GetData(int pageIndex, string Study_State, string Series_Modality, string StartTime, string EndTime)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectString_Center))
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = sqlConnection;
                    string searchsql = $@"SELECT row_number() over (order by id asc) as rownumber,
	                                        [id] ,
	                                        [study_uid],
	                                        [patient_id],
	                                        [study_accession_number],
	                                        [study_path],
	                                        [series_modality],
	                                        [series_count],
	                                        [instance_count],
                                        CASE
		                                        [study_state] 
		                                        WHEN 0 THEN
		                                        '未打印' ELSE '已打印' 
	                                        END AS study_state,
	                                        [study_data_time],
	                                        [study_transfer_time] 
                                        FROM
	                                        [dbo].[study] 
                                        WHERE
	                                        1 = 1";
                    cmd.CommandText = $@"select top {pageSize} * from (
                                        {searchsql} ";

                    string sqlstr = cmd.CommandText;
                    if (!string.IsNullOrEmpty(Study_State))
                    {
                        searchsql += $@"AND [PACSSelfService].[dbo].[study].[study_state]={Convert.ToInt32(Study_State)} ";
                    }
                    if (!string.IsNullOrEmpty(Series_Modality))
                    {
                        searchsql += $@"  AND [PACSSelfService].[dbo].[study].[series_modality]='{Series_Modality}'";
                    }
                    if (!string.IsNullOrEmpty(StartTime) && !string.IsNullOrEmpty(EndTime))
                    {
                        searchsql += $@"  AND [PACSSelfService].[dbo].[study].[study_data_time]   
                            BETWEEN '{Convert.ToDateTime(StartTime)}' AND  '{ Convert.ToDateTime(EndTime)}' ";
                    }
                    sqlstr += $@") temp  where rownumber>(({pageIndex}-1)*{pageSize})";

                    sqlConnection.Open();

                    using (SqlDataAdapter adapter = new SqlDataAdapter(sqlstr, sqlConnection))
                    {
                        DataSet ds = new DataSet();
                        adapter.Fill(ds, "study");
                        this.dataGrid1.ItemsSource = ds.Tables[0].DefaultView;
                        if (dataGrid1.ItemsSource == null)
                        {
                            return;
                        }
                    }
                    sqlConnection.Close();
                    label1.Content = Convert.ToString(pageIndex);
                    float count = DataCount(searchsql);
                    float pagesizecount = count / pageSize;
                    double i = Math.Ceiling(pagesizecount);
                    label2.Content = Convert.ToString(i);

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private int DataCount(string sql)
        {
            string countsql = $@"SELECT   COUNT(1)   FROM   ({sql}) AS T";
            SqlConnection conn = new SqlConnection(connectString_Center);
            SqlCommand cmd = new SqlCommand(countsql, conn);
            conn.Open();
            int i = (int)cmd.ExecuteScalar();
            conn.Close();
            return i;

        }

        private void Button7_Click(object sender, RoutedEventArgs e)
        {
            string study_state = txt_state.Text;
            string series_modality = txt_modality.Text;
            string starttime = date_starttime.Text;
            string endtime = date_endtime.Text;
            int pageindex = Convert.ToInt32(label1.Content);
            if (pageindex > 1)
            {
                GetData(pageindex - 1, study_state, series_modality, starttime, endtime);
            }
        }

        private void Button8_Click(object sender, RoutedEventArgs e)
        {
            string study_state = txt_state.Text;
            string series_modality = txt_modality.Text;
            string starttime = date_starttime.Text;
            string endtime = date_endtime.Text;
            int pageindex = Convert.ToInt32(label1.Content);
            int countindex = Convert.ToInt32(label2.Content);
            if (pageindex < countindex)
            {
                GetData(pageindex + 1, study_state, series_modality, starttime, endtime);
            }
        }

        private void Button9_Click(object sender, RoutedEventArgs e)
        {
            string study_state = txt_state.Text;
            string series_modality = txt_modality.Text;
            string starttime = date_starttime.Text;
            string endtime = date_endtime.Text;
            int pageindex = Convert.ToInt32(label1.Content);
            //调转到第n页
            if (Convert.ToInt32(textBox1.Text) >= 1 && Convert.ToInt32(textBox1.Text) <= Convert.ToInt32(label2.Content))
            {
                GetData(Convert.ToInt32(textBox1.Text), study_state, series_modality, starttime, endtime);
            }
        }
    }
}
